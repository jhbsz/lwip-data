#include <unistd.h>



_ssize_t _write_r (struct _reent *r, int file, const void *ptr, size_t len)
{
	
}

_ssize_t _read_r(struct _reent *r, int file, void *ptr, size_t len)
{

}
