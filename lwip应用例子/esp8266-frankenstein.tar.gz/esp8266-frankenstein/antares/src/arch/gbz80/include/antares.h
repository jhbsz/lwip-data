/* This is the generic fallback, ANTARES startup
 * can't be supported via sdcc at the time of
 * writing without too many hacks
 */

#include <generic/antares-nostartup.h>
#include <generic/antares.h>
