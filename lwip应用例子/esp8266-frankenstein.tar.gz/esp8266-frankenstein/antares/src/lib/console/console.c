
struct console { 
	int 
	char* out_buffer;
	int o_head, o_tail;
	char* in_buffer;
	int i_head, i_tail;
};
	

struct console { 
	void read
};

struct consoel
